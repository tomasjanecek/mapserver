<?php

// measure2 and drawing:
$_sl['Color'] = 'Color';
$_sl['Delete'] = 'Delete';
$_sl['Type'] = 'Type';
$_sl['Empty'] = 'Remove all';

// drawing:
$_sl['drawing_help'] = 'A simple click to begin, a double click to finished draw.<br />Delete last point with \'DEL\' key.';
$_sl['Point'] = 'Point';
$_sl['Line'] = 'Line';
$_sl['Polygon'] = 'Polygon';
$_sl['Circle'] = 'Circle';
$_sl['Index'] = 'Index';
$_sl['Comment'] = 'Comment';
$_sl['Add comment:'] = 'Add comment:';
$_sl['Outline'] = 'Outline';
$_sl['dblclick_error'] = 'A simple click to draw...';
$_sl['Drawing'] = 'Drawing';
$_sl['cat_drawing'] = 'Drawings';
$_sl['Rectangle'] = 'Rectangle';
$_sl['Annotation'] = 'Annotation';
$_sl['Radius'] = 'Radius';
$_sl['Circumference'] = 'Circumference';
$_sl['Area'] = 'Area';

?>