This is a small plugin for pmapper framework.
It just allow a timing map reload

It contains:
- config.inc: include the other files in pmapper
- timingmap.js: the function to execute for reloading the main map

Dependancies :
No dependancy

How to use:
Add the string "timingmap" to the plugins list in the pmapper config file.


Parameters:
to add to config file for to overwrite default values
 - delayTimingMap: interval time between realoding map event (ms, default 10000)