<?php

// unitAndProj
$_sl['unitAndProj__units'] = 'Unités';
$_sl['unitAndProj__0'] = 'pouces';
$_sl['unitAndProj__1'] = 'pieds';
$_sl['unitAndProj__2'] = 'milles';
$_sl['unitAndProj__3'] = 'mètres';
$_sl['unitAndProj__4'] = 'kilomètres';
$_sl['unitAndProj__5'] = 'dd';
$_sl['unitAndProj__6'] = 'pixels';
$_sl['unitAndProj__7'] = 'milles nautiques';
$_sl['unitAndProj__proj'] = 'Projection';
$_sl['unitAndProj__projNotDef'] = 'description non disponible';

?>