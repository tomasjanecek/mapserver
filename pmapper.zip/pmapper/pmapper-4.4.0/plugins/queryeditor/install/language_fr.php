<?php

// QueryEditor :
$_sl['QueryEditor'] = 'Editeur de requ�tes';
$_sl['Spatial datas'] = 'Donn�es g�ographiques';
$_sl['Layer name'] = 'Nom de la couche';
$_sl['Attribute'] = 'Attribut';
$_sl['Type'] = 'Type';
$_sl['Text'] = 'Texte';
$_sl['Numeric'] = 'Num�rique';
$_sl['Date'] = 'Date';
$_sl['Comparison'] = 'Comparaison';
$_sl['equal'] = '�gal';
$_sl['different'] = 'diff�rent';
$_sl['contains'] = 'contient';
$_sl['doesnot contain'] = 'ne contient pas';
$_sl['start with'] = 'commence par';
$_sl['end with'] = 'fini par';
$_sl['case sensitive'] = 'sensible � la casse';
$_sl['Value'] = 'Valeur';
$_sl['Add'] = 'Ajouter';
$_sl['Operator'] = 'Op�rateur';
$_sl['AND'] = 'ET';
$_sl['OR'] = 'OU';
$_sl['NOT'] = 'NON';
$_sl['Generated query'] = 'Requ�te g�n�r�e';
$_sl['Reset'] = 'Effacer';
$_sl['Apply'] = 'Appliquer';
$_sl['Cancel'] = 'Annuler';

?>