<?php

// QueryEditor :
$_sl['QueryEditor'] = 'Query editor';
$_sl['Spatial datas'] = 'Geographical data';
$_sl['Layer name'] = 'Layer\'s name';
$_sl['Attribute'] = 'Attribute';
$_sl['Type'] = 'Type';
$_sl['Text'] = 'Text';
$_sl['Numeric'] = 'Numeric';
$_sl['Date'] = 'Date';
$_sl['Comparison'] = 'Comparison';
$_sl['equal'] = 'equal';
$_sl['different'] = 'different';
$_sl['contains'] = 'contains';
$_sl['doesnot contain'] = 'doesn\'t contain';
$_sl['start with'] = 'start with';
$_sl['end with'] = 'end with';
$_sl['case sensitive'] = 'case sensitive';
$_sl['Value'] = 'Value';
$_sl['Add'] = 'Add';
$_sl['Operator'] = 'Operator';
$_sl['AND'] = 'AND';
$_sl['OR'] = 'OR';
$_sl['NOT'] = 'NOT';
$_sl['Generated query'] = 'Generated query';
$_sl['Reset'] = 'Reset';
$_sl['Apply'] = 'Apply';
$_sl['Cancel'] = 'Cancel';

?>