<?php

// selection management:
$_sl['selectionManagement_reloadMap'] = $_sl['Refresh Map'];
$_sl['selectionManagement_removeSelection'] = 'Suppression de la sélection courante';
$_sl['selectionManagement_reloadSelection'] = 'Recharger la sélection';
$_sl['selectionManagement_reloadError'] = 'Echec du chargement de la selection';
$_sl['selectionManagement_removeSelected__header'] = 'Exclure';
$_sl['selectionManagement_removeSelected__object'] = 'Exclure de la sélection courante';

$_sl['selectionManagement_selOperator_text'] = 'Opération sur les sélections';
$_sl['selectionManagement_selOperator_add_text'] = 'Ajouter à la sélection courante';
$_sl['selectionManagement_selOperator_del_text'] = 'Exclure de la sélection courante';
$_sl['selectionManagement_selOperator_intersec_text'] = 'Intersection avec la sélection courante';
$_sl['selectionManagement_selOperator_new_text'] = 'Remplacer la sélection';

$_sl['selectionManagement_savSelectionDlg'] = 'Gestionnaire de sauvegarde de sélection';
$_sl['selectionManagement_renameSelectionDlg'] = 'Renommer la sélection ...';
$_sl['selectionManagement_saveSelection'] = 'Sauvegarder la sélection courante';
$_sl['selectionManagement_selectionName'] = 'Nom';
$_sl['selectionManagement_selectionColor'] = 'Couleur';
$_sl['selectionManagement_noSelection'] = 'Aucune sélection sauvegardée.';
$_sl['selectionManagement_selList'] = 'Sélections sauvegardées';
$_sl['selectionManagement_delSelection'] = 'Supprimer la sélection';
$_sl['selectionmanagement_selectionCategory'] = 'Sélections';
$_sl['selectionManagement_newSelectionCaption'] = 'Nouvelle sélection';

$_sl['selectionManagement_btnShowSavSelTitle'] = 'Afficher les sauvegardes sélectionnées';
$_sl['selectionManagement_btnHideSavSelTitle'] = 'Cacher les sauvegardes sélectionnées';
$_sl['selectionManagement_btnDeleteSavSelTitle'] = 'Supprimer les sauvegardes sélectionnées';
$_sl['selectionManagement_btnReloadSavSelTitle'] = 'Recharger les sauvegardes sélectionnées';
$_sl['selectionManagement_btnAddSavSelTitle'] = 'Ajouter sauvegardes sélectionnées à la sélection courante';
$_sl['selectionManagement_btnIntersectSavSelTitle'] = 'Sélectionner l\'intersection des sauvegardes sélectionnées et de la sélection courante';
$_sl['selectionManagement_btnExcludeSavSelTitle'] = 'Exclure les sauvegardes sélectionnées de la sélection courante';
$_sl['selectionManagement_currentSelectionName'] = 'Sélection courante';
$_sl['selectionManagement_menuSaveSelection'] = 'Sauvegarder la sélection';

$_sl['selectionManagement_renameSelectionCommande'] = '"Entrée" : valider, "Escape" : annuler';

$_sl['selectionManagement_menuSelectionName'] = 'Sélection';

$_sl['type_point'] = 'Ponctuel';
$_sl['type_line'] = 'Lineaire';
$_sl['type_poly'] = 'Surfacique';

?>