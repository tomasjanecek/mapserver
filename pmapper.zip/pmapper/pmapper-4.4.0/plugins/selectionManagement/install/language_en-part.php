<?php

// selection management:
$_sl['selectionManagement_reloadMap'] = $_sl['Refresh Map'];
$_sl['selectionManagement_removeSelection'] = 'Remove current selection';
$_sl['selectionManagement_reloadSelection'] = 'Reload selection';
$_sl['selectionManagement_reloadError'] = 'Error during selection loading';
$_sl['selectionManagement_removeSelected__header'] = 'Remove';
$_sl['selectionManagement_removeSelected__object'] = 'Remove';

$_sl['selectionManagement_selOperator_text'] = 'Operation on selections';
$_sl['selectionManagement_selOperator_add_text'] = 'Add to current selection';
$_sl['selectionManagement_selOperator_del_text'] = 'Exclude from the current selection';
$_sl['selectionManagement_selOperator_intersec_text'] = 'Intersect with current selectione';
$_sl['selectionManagement_selOperator_new_text'] = 'Replace selection';

$_sl['selectionManagement_savSelectionDlg'] = 'Save selection box';
$_sl['selectionManagement_saveSelection'] = 'Save current selection';
$_sl['selectionManagement_selectionName'] = 'Name';
$_sl['selectionManagement_selectionColor'] = 'Color';
$_sl['selectionManagement_noSelection'] = 'No saved selection.';
$_sl['selectionManagement_selList'] = 'Saved selections';
$_sl['selectionManagement_delSelection'] = 'Delete selection';
$_sl['selectionmanagement_selectionCategory'] = 'Selections';
$_sl['selectionManagement_newSelectionCaption'] = 'New selection';

$_sl['selectionManagement_btnShowSavSelTitle'] = 'Show selections';
$_sl['selectionManagement_btnHideSavSelTitle'] = 'Hide selections';
$_sl['selectionManagement_btnDeleteSavSelTitle'] = 'Delete selections';
$_sl['selectionManagement_btnReloadSavSelTitle'] = 'Reload selections';
$_sl['selectionManagement_btnAddSavSelTitle'] = 'Add to current selection';
$_sl['selectionManagement_btnIntersectSavSelTitle'] = 'Intersect with current selection';
$_sl['selectionManagement_btnExcludeSavSelTitle'] = 'Exclude from current selection';
$_sl['selectionManagement_currentSelectionName'] = 'Current selection';
$_sl['selectionManagement_menuSaveSelection'] = 'Save selection';

$_sl['selectionManagement_btnDeleteSavSelName'] = 'Delete';
$_sl['selectionManagement_btnDeleteSavSelTitle'] = 'Delete selected items';
$_sl['selectionManagement_btnReloadSavSelName'] = 'Reload';
$_sl['selectionManagement_btnReloadSavSelTitle'] = 'Reload selected items';

$_sl['selectionManagement_renameSelectionCommande'] = '"Return" : validate, "Escape" : cancel';

$_sl['selectionManagement_menuSelectionName'] = 'Selection';

$_sl['type_point'] = 'Point';
$_sl['type_line'] = 'Line';
$_sl['type_poly'] = 'Polygon';

?>