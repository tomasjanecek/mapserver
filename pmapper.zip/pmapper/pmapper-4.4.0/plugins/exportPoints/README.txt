Export Points plugin: export coordinates of point in txt file
  
It contains:
- config.inc: include the other files in pmapper
- exportPoints.js: plugin code
- projection.php: Projection class to convert point coordinates
- x_getProjList.php: return the list of available projection to convert points
- x_pointsExport.php: write the file with point's coordinates
- install subdirectory: files needed for installation / configuration

Dependancies:
- plugins/drawing_base/drawing_base.js: use some functions from drawing_base parent class 
- plugins/common/common.js: some common functions (colors, ...) 
- javascript/src/pm.geometry.js: geometry library for measurements and digitizing.
- plugins/clientdynamiclayers/*: dynamic layers functionality
- config/common/template.map: template mapfile that contains layers definition to add dynamically
- unitAndProj plugin to get choice of projection (maybe just for unit translation ?)

How to use:

- Enable the plugin by adding a line in config_XXXXX.xml file:
<pmapper>
    <ini>
        <pmapper>
....
            <plugins>unitAndProj</plugins>
            <plugins>exportPoints</plugins>
....
        </pmapper>
	</ini>
</pmapper>

- Add the pointing tool button to the interface in /config/XXXXX/js_config.php file:
PM.buttonsDefault = {
.....
    buttons: [
.....
		{tool:'exportPoints',   name:'ExportPoints'},
.....
	]
}

- See unitAndProj plugin Readme.txt to set the correct configuration. Be sure that espg code set in unitAndProj configuration are declared in epsg file.

- Set default plugin configuration by adding a line in config_XXXXX.xml file:
<pmapper>
   <ini>
....
        <pluginsConfig>
....        
			<exportPoints>
				<!-- dialog type to use -->
	        	<dlgType>dynwin</dlgType>
				<!-- default color -->
				<default_color>#1AC7F2</default_color>
				<!-- default outline color -->
				<default_outlineColor>#595959</default_outlineColor>
					
				<!-- point drawing parameters -->
				<point>
					<draw>
						<defaultSymbol>circle</defaultSymbol>
						<defaultThickness>10</defaultThickness>
					</draw>	
					<label>
						<defaultFont>FreeSans</defaultFont>
						<defaultTextSize>10</defaultTextSize>
					</label>
				</point>
				<!-- Define available projections -->
				<!--
				If unitAndProj or coordinates plugin are activated before this one,
				man can use an empty <projections> tag to use theirs projections.
				-->
				<projections></projections>
        	</exportPoints>
....
        </pluginsConfig>
    </ini>
</pmapper>  

- Add icon from plugins/exportPoints/install/exportPoints_off.gif to images/buttons/default (or the corresponding theme directory)

- the point symbol used in your your configuration file (<defaultSymbol>XXXXX</defaultSymbol>) have to be defined in your mapfile and in the template mapfile (by default config/common/template.map). Examples are provided in plugins/exportPoints/install/symbol-part.map. It could be a good thing top add them in the '# Symbols used in p.mapper' part...

- Add the appropriate layers from plugins/exportPoints/install/template-part.map to your template.map (by default config/common/template.map). Be carreful to respect the correct mapfile syntax / nesting

- Add default translation from plugins/exportPoints/install/language_en-part.php to incphp/locale/language_en.php. You can add translations for other language (French is provided) by doing the same.