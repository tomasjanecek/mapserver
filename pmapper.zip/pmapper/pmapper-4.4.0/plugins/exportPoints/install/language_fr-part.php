<?php

// measure2 and drawing:
$_sl['Delete'] = 'Supprimer';
$_sl['Empty'] = 'Vider';

// exportPoints:
$_sl['exportPoints_help'] = 'Fichier de points';
$_sl['exportPoints_help'] = 'Cliquez sur la carte pour enregistrer des points.';
$_sl['exportPoints_projNotdef'] = 'Description de la projection non disponible';
$_sl['exportPoints_dosUnit'] = 'Unité de la carte';
$_sl['exportPoints_dosProj'] = 'Projection de la carte';
$_sl['exportPoints_targetProj'] = 'Projection demandée';
$_sl['cat_exportPoints'] = 'Points enregistrés';

?>