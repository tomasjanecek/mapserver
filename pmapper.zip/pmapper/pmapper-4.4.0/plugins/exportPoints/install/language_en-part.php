<?php

// measure2 and drawing:
$_sl['Delete'] = 'Delete';
$_sl['Empty'] = 'Remove all';

// exportPoints:
$_sl['exportPoints_help'] = 'Points file';
$_sl['exportPoints_help'] = 'Clic on map to record points.';
$_sl['exportPoints_projNotdef'] = 'Projection description not available';
$_sl['exportPoints_dosUnit'] = 'Map unit';
$_sl['exportPoints_dosProj'] = 'Map projection';
$_sl['exportPoints_targetProj'] = 'Wanted Projection';
$_sl['cat_exportPoints'] = 'Recorded points';

?>