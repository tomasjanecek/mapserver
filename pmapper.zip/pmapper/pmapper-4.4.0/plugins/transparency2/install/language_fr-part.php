<?php

// transparency2
$_sl['transparency2_reset_default'] = 'Transparence initiale';
$_sl['transparency2_resetAll_default'] = 'Transparence initiale de tous les groupes';

?>