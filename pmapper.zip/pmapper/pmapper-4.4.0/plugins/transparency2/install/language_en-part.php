<?php

// transparency2
$_sl['transparency2_reset_default'] = 'Reset default transparency';
$_sl['transparency2_resetAll_default'] = 'Reset default transparency to all groups';

?>