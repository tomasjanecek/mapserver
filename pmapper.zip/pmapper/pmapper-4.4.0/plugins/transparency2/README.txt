Transparency2 plugin:
- add a slider for each groups / layer in TOC
- can add buttons to restore layer(s) initial transparency level

It contains:
- config.inc: include the other files in pmapper
- transparency2.css: styles for sliders
- transparency2.js: plugin code and redefine "PM.Plugin.Transparency" and setGroupTransparency function to add a small part of code concerning sliders

Dependancies:
Plugin transparency present im pmapper installation, but activated or not.

How to use:
- Enable the plugin by adding a line in config_XXXXX.xml file:
<pmapper>
    <ini>
        <pmapper>
....
            <plugins>transparency2</plugins>
....
        </pmapper>
	</ini>
</pmapper>
- Specify if sliders have to represent opacity or transparency by adding in config_XXXXX.xml file:
<pmapper>
    <ini>
....
        <pluginsConfig>
....
			<transparency2>
				<useOpacity>off</useOpacity>
			</transparency2>
....
        </pluginsConfig>
    </ini>
</pmapper>

- Add the tools to context menu in /config/XXXXX/js_config.php file:
PM.contextMenuList = [     
    // layers/group in TOC
    {bindto: 'li.tocgrp',        
     menuid: 'cmenu_tocgroup',
     menulist: [   
...
		{id:'transparency-reset', imgsrc:'transparency_reset-b.png', text:'transparency2_reset_default', run:'PM.Plugin.Transparency2.resetDefaultTransparency'},
		{id:'transparency-resetAll', imgsrc:'transparency_resetAll-b.png', text:'transparency2_resetAll_default', run:'PM.Plugin.Transparency2.resetAllDefaultTransparency'},
...
        ], 
     styles: {menuStyle: {width:'auto'}}
    },
...
];

- Add the appropriate images from plugins/transparency2/install/images/ to images/menus

- Add default translation from plugins/transparency2/install/language_en-part.php to incphp/locale/language_en.php.
You can add translations for other language (French is provided) by doing the same.


TO DO:
add sliders tooltip
