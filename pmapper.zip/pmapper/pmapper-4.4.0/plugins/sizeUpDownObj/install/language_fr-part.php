<?php

// sizeUpDownObj
$_sl['sizeUpDownObj_size_up'] = 'Augmenter la taille des objets';
$_sl['sizeUpDownObj_size_down'] = 'Réduire la taille des objets';
$_sl['sizeUpDownObj_size_reset'] = 'Réinitialiser la taille des objets';
$_sl['sizeUpDownObj_size_resetall'] = 'Réinitialiser la taille de tous les niveaux';
$_sl['sizeUpDownObj_ret_1'] = 'La limite d\'agrandissement est atteinte.';
$_sl['sizeUpDownObj_ret_2'] = 'La limite de diminution est atteinte.';
$_sl['sizeUpDownObj_Caption'] = 'Modification de la taille des objets.';
$_sl['sizeUpDownObj_labelScale_up'] = 'Augmenter l\'échelle de visibilité des textes.';
$_sl['sizeUpDownObj_labelScale_reset'] = 'Réinitialiser l\'échelle de visibilité des textes';
$_sl['sizeUpDownObj_labelScale_resetAll'] = 'Réinitialiser l\'échelle de visibilité de tous les textes';
$_sl['sizeUpDownObj_labelScale_scaleTooSmall_1'] = 'L\'échelle courante est trop petite.';
$_sl['sizeUpDownObj_labelScale_scaleTooSmall_2'] = 'Zoomez plus avant pour afficher les textes';

?>