<?php

// sizeUpDownObj
$_sl['sizeUpDownObj_size_up'] = 'Increase objets size';
$_sl['sizeUpDownObj_size_down'] = 'Decrease objets size';
$_sl['sizeUpDownObj_size_reset'] = 'Reset objets size';
$_sl['sizeUpDownObj_size_resetall'] = 'Reset all layers size';
$_sl['sizeUpDownObj_ret_1'] = 'Max increase iteration reached.';
$_sl['sizeUpDownObj_ret_2'] = 'Max decrease iteration reached.';
$_sl['sizeUpDownObj_Caption'] = 'Update objets size.';
$_sl['sizeUpDownObj_labelScale_up'] = 'Increase labels scale limit';
$_sl['sizeUpDownObj_labelScale_reset'] = 'Reset labels scale limit';
$_sl['sizeUpDownObj_labelScale_resetAll'] = 'Reset all labels scale limit';
$_sl['sizeUpDownObj_labelScale_scaleTooSmall_1'] = 'Scale is too small.';
$_sl['sizeUpDownObj_labelScale_scaleTooSmall_2'] = 'Zoom to show label';

?>