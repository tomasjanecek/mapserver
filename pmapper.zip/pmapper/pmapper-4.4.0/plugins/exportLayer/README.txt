Export layer plugin: simply add button in layer menu in order to export its data

POSTGIS and ORACLE only!!!

Dependancies:
- plugins/export/shp/: projection definitions
- PDO
- plugins/common/groupsAndLayers.php
- plugins/common/easyMDB2.inc.php

How to use:

- Enable the plugin by adding a line in config_XXXXX.xml file:
<pmapper>
    <ini>
        <pmapper>
....
            <plugins>exportLayer</plugins>
....
        </pmapper>
	</ini>
</pmapper>

- Add the tools to context menu in /config/XXXXX/js_config.php file:
PM.contextMenuList = [     
    // layers/group in TOC
    {bindto: 'li.tocgrp',        
     menuid: 'cmenu_tocgroup',
     menulist: [   
...
        {id:'exportLayer',   imgsrc:'exportLayer-b.png', text:'expLayer_title',   run:'PM.Plugin.ExportLayer.cmExportLayer'},
...
        ], 
     styles: {menuStyle: {width:'auto'}}
    },
...
];

- Set default plugin configuration by adding a line in config_XXXXX.xml file:

</pmapper>
	</ini>
...
		</pluginsConfig>
...
			<exportLayer>
				<!-- Max execution time for PHP -->
				<timeLimit>60</timeLimit>
				<!-- Number of object to export (limit) -->
				<nbObjLimit>150000</nbObjLimit>
			</exportLayer>
...
		</pluginsConfig>
	</ini>
</pmapper>


- Add the appropriate images from plugins/sizeUpDownObj/install/images/ to images/menus

- Add default translation from plugins/exportLayer/install/language_en-part.php to incphp/locale/language_en.php.
You can add translations for other language (French is provided) by doing the same.
