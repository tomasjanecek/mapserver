<?php

// exportLayer
$_sl['expLayer_title'] = 'Export de la couche';
$_sl['expLayer_filterTitle'] = 'Sélection des filtres';
$_sl['expLayer_filter'] = 'Filtre';
$_sl['expLayer_nbObj'] = 'Objet';
$_sl['expLayer_btnExport'] = 'Exporter';
$_sl['expLayer_btnCancel'] = 'Annuler';
$_sl['expLayer_waitingCancel'] = 'En attente d\'annulation';
$_sl['expLayer_exportCanceled'] = 'Export annulé';
$_sl['expLayer_exportInProgress'] = 'Un export est déjà en cours';
$_sl['expLayer_errTimeout'] = 'Délai d\'attente dépassé';
$_sl['expLayer_errMemory'] = 'Mémoire insuffisante';
$_sl['expLayer_error'] = 'Une erreur c\'est produite durant l\'export';

?>